  <footer class="page-footer">
    <div class="container">
      <p id="copyright">Copyright &copy; 2024 <a href="#"><span class="text-primary">Tech</span>Care</a>. All right reserved</p>
    </div>
  </footer>

<script src="assets/js/jquery-3.5.1.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/wow/wow.min.js"></script>
<script src="assets/js/theme.js"></script>
  
</body>
</html>